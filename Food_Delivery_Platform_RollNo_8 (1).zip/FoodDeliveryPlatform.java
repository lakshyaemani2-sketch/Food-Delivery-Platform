import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

// Project 2: Food Delivery Platform (Swiggy / Zomato style)
// Student Roll Number: 8
public class FoodDeliveryPlatform {

    enum OrderStatus {
        PLACED, PREPARING, ON_THE_WAY, DELIVERED
    }

    interface DiscountStrategy {
        double applyDiscount(double amount);
    }

    static class CouponDiscount implements DiscountStrategy {
        public double applyDiscount(double amount) {
            return amount >= 300 ? amount * 0.10 : 0.0; // 10% off on bills of Rs.300 or more
        }
    }

    static class RestaurantClosedException extends Exception {
        RestaurantClosedException(String message) {
            super(message);
        }
    }

    static class Restaurant {
        String name;
        boolean open;
        ArrayList<String> menu = new ArrayList<>();

        Restaurant(String name, boolean open) {
            this.name = name;
            this.open = open;
            menu.add("Veg Burger - 120");
            menu.add("Pizza - 250");
            menu.add("Veg Biryani - 180");
            menu.add("Sandwich - 100");
        }
    }

    static class Customer {
        String name;
        Customer(String name) { this.name = name; }
    }

    static class DeliveryPartner {
        String name;
        boolean available = true;
        DeliveryPartner(String name) { this.name = name; }
    }

    static class MenuItem {
        String name;
        double price;
        MenuItem(String name, double price) {
            this.name = name;
            this.price = price;
        }
    }

    static class OrderItem {
        MenuItem item;
        int quantity;
        OrderItem(MenuItem item, int quantity) {
            this.item = item;
            this.quantity = quantity;
        }
        double total() { return item.price * quantity; }
    }

    static class Order {
        int orderId;
        Customer customer;
        ArrayList<OrderItem> items;
        OrderStatus status;
        double bill;
        String partner;

        Order(int id, Customer customer, ArrayList<OrderItem> items,
              double bill, String partner) {
            this.orderId = id;
            this.customer = customer;
            this.items = new ArrayList<>(items);
            this.bill = bill;
            this.partner = partner;
            this.status = OrderStatus.PLACED;
        }
    }

    static class OrderProcessor implements Runnable {
        private final Order order;
        private final Runnable refreshScreen;

        OrderProcessor(Order order, Runnable refreshScreen) {
            this.order = order;
            this.refreshScreen = refreshScreen;
        }

        public void run() {
            try {
                Thread.sleep(2500);
                order.status = OrderStatus.PREPARING;
                SwingUtilities.invokeLater(refreshScreen);

                Thread.sleep(2500);
                order.status = OrderStatus.ON_THE_WAY;
                SwingUtilities.invokeLater(refreshScreen);

                Thread.sleep(2500);
                order.status = OrderStatus.DELIVERED;
                SwingUtilities.invokeLater(refreshScreen);
                saveOrder(order);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    static HashMap<Integer, Order> orderHistory = new HashMap<>();
    static Queue<DeliveryPartner> partnerQueue = new LinkedList<>();
    static int nextOrderId = 1001;

    static synchronized DeliveryPartner assignPartner() {
        DeliveryPartner partner = partnerQueue.poll();
        if (partner != null) {
            partnerQueue.offer(partner); // rotate partners for fair assignment
        }
        return partner;
    }

    static synchronized void saveOrder(Order order) {
        try (FileWriter writer = new FileWriter("order_history.txt", true)) {
            writer.write("Order ID: " + order.orderId
                    + " | Customer: " + order.customer.name
                    + " | Amount: Rs." + String.format("%.2f", order.bill)
                    + " | Partner: " + order.partner
                    + " | Status: " + order.status
                    + " | Time: " + LocalDateTime.now().format(
                      DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")) + "\n");
        } catch (IOException e) {
            System.out.println("Could not save order history: " + e.getMessage());
        }
    }

    static void showWindow() {
        Restaurant restaurant = new Restaurant("MNR Food Corner", true);
        partnerQueue.offer(new DeliveryPartner("Ravi"));
        partnerQueue.offer(new DeliveryPartner("Kiran"));
        partnerQueue.offer(new DeliveryPartner("Arjun"));

        JFrame frame = new JFrame("Food Delivery Platform - Roll No. 8");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(760, 600);
        frame.setLocationRelativeTo(null);

        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JLabel heading = new JLabel("FOOD DELIVERY PLATFORM", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        main.add(heading, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        JTextField customerField = new JTextField();
        JComboBox<String> foodBox = new JComboBox<>(new String[]{
                "Veg Burger - Rs.120", "Pizza - Rs.250",
                "Veg Biryani - Rs.180", "Sandwich - Rs.100"
        });
        JSpinner quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        JTextArea output = new JTextArea(13, 40);
        output.setEditable(false);
        output.setFont(new Font("Monospaced", Font.PLAIN, 13));

        form.add(new JLabel("Customer Name:"));
        form.add(customerField);
        form.add(new JLabel("Select Food:"));
        form.add(foodBox);
        form.add(new JLabel("Quantity:"));
        form.add(quantitySpinner);

        JButton placeButton = new JButton("Place Order");
        JButton clearButton = new JButton("Clear");
        form.add(placeButton);
        form.add(clearButton);

        main.add(form, BorderLayout.CENTER);
        main.add(new JScrollPane(output), BorderLayout.SOUTH);
        frame.add(main);

        placeButton.addActionListener(event -> {
            try {
                String customerName = customerField.getText().trim();
                if (customerName.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please enter customer name.");
                    return;
                }
                if (!restaurant.open) {
                    throw new RestaurantClosedException("Restaurant is currently closed.");
                }

                String selected = (String) foodBox.getSelectedItem();
                String[] parts = selected.split(" - Rs\\.");
                String foodName = parts[0];
                double price = Double.parseDouble(parts[1]);
                int quantity = (Integer) quantitySpinner.getValue();

                ArrayList<OrderItem> cart = new ArrayList<>();
                cart.add(new OrderItem(new MenuItem(foodName, price), quantity));

                double subtotal = cart.get(0).total();
                DiscountStrategy discount = new CouponDiscount();
                double discountAmount = discount.applyDiscount(subtotal);
                double deliveryCharge = 30.0;
                double finalBill = subtotal - discountAmount + deliveryCharge;

                DeliveryPartner partner = assignPartner();
                if (partner == null) {
                    JOptionPane.showMessageDialog(frame, "No delivery partner available.");
                    return;
                }

                Order order = new Order(nextOrderId++, new Customer(customerName),
                        cart, finalBill, partner.name);
                orderHistory.put(order.orderId, order);

                output.append("Order ID: " + order.orderId + "\n");
                output.append("Customer: " + customerName + "\n");
                output.append("Restaurant: " + restaurant.name + "\n");
                output.append("Food: " + foodName + " x " + quantity + "\n");
                output.append("Subtotal: Rs." + String.format("%.2f", subtotal) + "\n");
                output.append("Discount: Rs." + String.format("%.2f", discountAmount) + "\n");
                output.append("Delivery Charge: Rs.30.00\n");
                output.append("Total Bill: Rs." + String.format("%.2f", finalBill) + "\n");
                output.append("Delivery Partner: " + partner.name + "\n");
                output.append("Status: " + order.status + "\n");
                output.append("----------------------------------------\n");

                placeButton.setEnabled(false);
                Thread processor = new Thread(new OrderProcessor(order, () -> {
                    output.append("Order " + order.orderId + " Status: " + order.status + "\n");
                    if (order.status == OrderStatus.DELIVERED) {
                        output.append("Order saved to order_history.txt\n");
                        output.append("----------------------------------------\n");
                        placeButton.setEnabled(true);
                    }
                }));
                processor.start();

            } catch (RestaurantClosedException ex) {
                JOptionPane.showMessageDialog(frame, ex.getMessage());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            } finally {
                // This block runs whether the order succeeds or an exception occurs.
            }
        });

        clearButton.addActionListener(event -> {
            customerField.setText("");
            quantitySpinner.setValue(1);
            output.setText("");
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FoodDeliveryPlatform::showWindow);
    }
}
