# Food Delivery Platform (Swiggy / Zomato Style)

**Project Number:** 2  
**Student Roll Number:** 8  
**Technology:** Java, Swing, Collections, Threads, File Handling

## Aim
To simulate the full life of a food order, from placing it to delivery.

## Features
- Enter customer name and select food and quantity.
- Calculate subtotal, coupon discount and delivery charge.
- Assign a delivery partner using a Queue.
- Update order status using a separate thread.
- Store completed orders in `order_history.txt`.
- Display order details in a Java Swing GUI.

## Java concepts used
Classes and objects, enum, interface, custom exception, ArrayList, HashMap, Queue, Runnable thread, file handling, try-catch-finally, Swing and event handling.

## How to run
1. Install JDK (Java 8 or later).
2. Open a terminal in this project folder.
3. Compile: `javac FoodDeliveryPlatform.java`
4. Run: `java FoodDeliveryPlatform`
5. Enter a customer name, select food and quantity, then click **Place Order**.
6. After the order reaches DELIVERED, check `order_history.txt` in the same folder.

## Sample output
See `Sample_Output.txt`.

## Note
This is a classroom simulator. It does not connect to real restaurants, payment services, GPS or delivery partners.
